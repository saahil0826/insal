A Pen created at CodePen.io. You can find this one at https://codepen.io/jasperlachance/pen/QNMwBg.

 This is a pretty simple effect to achieve for any header or content areas. This effect is particularly great for space-inspired content or perhaps networks/networking.

This is a Codrops creation that I'm currently playing with. Pretty neat. Be sure to check out the original [here](http://tympanus.net/codrops/2014/09/23/animated-background-headers/)