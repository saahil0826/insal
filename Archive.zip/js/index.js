

$("#myDIV").click(function(){
    $("more").hide();
});

$("#myDIV").click(function(){
    $("more").show();
});


function Hey(){
    document.getElementById('myModal')
}
