$(document).ready(function() {
  $(".view").click(function(){
  $('.more').fadeOut();
});
});
